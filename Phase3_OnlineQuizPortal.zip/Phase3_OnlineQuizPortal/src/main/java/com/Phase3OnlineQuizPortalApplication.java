package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Phase3OnlineQuizPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(Phase3OnlineQuizPortalApplication.class, args);
	}

}
